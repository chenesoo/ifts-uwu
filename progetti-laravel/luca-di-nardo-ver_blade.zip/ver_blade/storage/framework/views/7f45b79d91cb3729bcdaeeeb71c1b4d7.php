<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Libro creato</title>
    <?php echo $__env->make('bootstrap', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>

    <div class="container">
        <h3>Libro inserito con successo</h3>

        <a href="/books">Torna alla lista dei libri</a>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\TUTTI-I-REPOSITORY\progetti-laravel\ver_blade\resources\views/books/feedback/created.blade.php ENDPATH**/ ?>