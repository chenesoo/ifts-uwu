<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Elenco Books</title>
    <?php echo $__env->make('bootstrap', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="container">

        <h1>Lista dei libri</h1>
        <a href="/books/create">Inserisci nuovo libro</a>
        <table class="table">
            <thead>
                <tr>
                    <th>Titolo</th>
                    <th>Autore</th>
                    <th>Abstract</th>
                    <th>Pages</th>
                    <th>Rating</th>
                    <th>Azioni</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($book->title); ?></td>
                        <td><?php echo e($book->author); ?></td>
                        <td><?php echo e($book->abstract); ?></td>
                        <td><?php echo e($book->pages); ?></td>
                        <td><?php echo e($book->rating); ?></td>
                        <td>
                            <a href="/books/edit/<?php echo e($Book->id); ?>">Modifica</a>
                            <a href="/books/delete/<?php echo e($Book->id); ?>">Elimina</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\TUTTI-I-REPOSITORY\progetti-laravel\ver_blade\resources\views/Books/index.blade.php ENDPATH**/ ?>